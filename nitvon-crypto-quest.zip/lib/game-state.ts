"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"

export interface Player {
  name: string
  level: number
  xp: number
  rank: string
  portfolio: number
  coins: number
}

export interface GameState {
  currentScreen: "menu" | "intro" | "dashboard" | "event" | "minigame" | "leaderboard" | "shop"
  player: Player
  isGameStarted: boolean
  showLevelUpModal: boolean
  previousLevel: number

  // Actions
  setScreen: (screen: GameState["currentScreen"]) => void
  startGame: () => void
  updatePlayer: (updates: Partial<Player>) => void
  addXP: (amount: number) => void
  addCoins: (amount: number) => void
  setShowLevelUpModal: (show: boolean) => void
}

const initialPlayer: Player = {
  name: "Rookie Trader",
  level: 1,
  xp: 0,
  rank: "Rookie Trader",
  portfolio: 1000,
  coins: 100,
}

export const useGameState = create<GameState>()(
  persist(
    (set, get) => ({
      currentScreen: "menu",
      player: initialPlayer,
      isGameStarted: false,
      showLevelUpModal: false,
      previousLevel: 1,

      setScreen: (screen) => set({ currentScreen: screen }),

      startGame: () =>
        set({
          isGameStarted: true,
          currentScreen: "intro",
        }),

      updatePlayer: (updates) =>
        set((state) => ({
          player: { ...state.player, ...updates },
        })),

      addXP: (amount) =>
        set((state) => {
          const newXP = state.player.xp + amount
          const newLevel = Math.floor(newXP / 100) + 1
          let newRank = state.player.rank

          // Update rank based on level
          if (newLevel >= 10) newRank = "Legendary Trader"
          else if (newLevel >= 8) newRank = "Whale"
          else if (newLevel >= 6) newRank = "Pro Trader"
          else if (newLevel >= 4) newRank = "Market Analyst"
          else if (newLevel >= 2) newRank = "Street Trader"

          const leveledUp = newLevel > state.player.level

          return {
            player: {
              ...state.player,
              xp: newXP,
              level: newLevel,
              rank: newRank,
            },
            showLevelUpModal: leveledUp,
            previousLevel: state.player.level,
          }
        }),

      addCoins: (amount) =>
        set((state) => ({
          player: {
            ...state.player,
            coins: state.player.coins + amount,
          },
        })),

      setShowLevelUpModal: (show) => set({ showLevelUpModal: show }),
    }),
    {
      name: "nitvon-game-state",
    },
  ),
)
